In this data/train folder,

Create sub-folders of all the classes of images. For example, if you want to train your system with 3 classes - Chair, Motorcycle and Soccer Ball, create the following sub-folders:
```
data
 |
 |-train
     |
     |-Chair
         |
         |-ChairImag001.jpg
         |-ChairImg002.jpg
         |.....
     |-Motocrycle
         |
         |-Motorcycle001.jpg
         |-Motorcycle002.jpg
         |.....
     |-Soccer Ball
         |-Soccer_Ball-001.jpg
         |-Soccer_Ball-002.jpg
```   
If you have any more classes, create the sub-folders in the above similar fashion.
